# -*- coding: utf-8 -*-
"""
this is Baldness(Alopecia) Detection

"""
from flask import Flask,request,render_template,flash,url_for
from werkzeug import secure_filename
from joblib import load
import datetime
import shutil
import os


import cv2

app = Flask(__name__)
app.secret_key = os.urandom(24)
access_rights = 0o755
@app.route("/")
def home():
    return render_template("home.html")
    
@app.route("/predict",methods=["POST","GET"])
def predict():
    if request.method == 'POST':
      dirpath = "static/predict_image"
      if os.path.exists(dirpath):
          shutil.rmtree(dirpath)
      if not os.path.exists(dirpath): 
          os.mkdir(dirpath,access_rights)  
      print(os.listdir("static/predict_image"))
      f = request.files['file']
      f.save("static/predict_image/"+secure_filename("image_predict"+str(datetime.datetime.now().time())+".jpg"))
      
      clf = load("randomForest.model")
      image_w,image_h = [98,98]
      imageName = os.listdir("static/predict_image")[0]
      X = []
      X.append(cv2.resize(cv2.imread("static/predict_image/"+imageName,0),(image_w,image_h)).flatten()/255)
      #result =""
      if clf.predict(X)[0] == 0:
          flash("Image is Detected as -> BALD","result")
          #result ="Image is Detected as -> BALD"
          print()
      if clf.predict(X)[0] == 1:
          flash("Image is Detected as -> NORMAL","result")
      #img = "<img src='/static/image_predict.jpg' alt='Image Uploaded'>"
      img ='<img src=' + url_for('static',filename='predict_image/'+imageName) +' height="200px" width="200px"'+ '>' 
      print(img)
      return render_template("predict.html",img=img)
    
if __name__ == "__main__":
    app.run()